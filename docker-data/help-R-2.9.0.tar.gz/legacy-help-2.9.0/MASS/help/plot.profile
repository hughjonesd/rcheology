plot.profile              package:MASS              R Documentation

_P_l_o_t_t_i_g _F_u_n_c_t_i_o_n_s _f_o_r '_p_r_o_f_i_l_e' _O_b_j_e_c_t_s

_D_e_s_c_r_i_p_t_i_o_n:

     'plot' and 'pairs' methods for objects of class '"profile"'.

_U_s_a_g_e:

     ## S3 method for class 'profile':
     plot(x, ...)
     ## S3 method for class 'profile':
     pairs(x, colours = 2:3, ...)

_A_r_g_u_m_e_n_t_s:

       x: an object inheriting from class '"profile"'.

 colours: Colours to be used for the mean curves conditional on 'x' and
          'y' respectively.

     ...: arguments passed to or from other methods.

_D_e_t_a_i_l_s:

     This is the main 'plot' method for objects created by
     'profile.glm'.  It can also be called on objects created by
     'profile.nls', but they have a specific method,
     'plot.profile.nls'.

     The 'pairs' method shows, for each pair of parameters x and y, two
     curves intersecting at the maximum likelihood estimate, which give
     the loci of the points at which the tangents to the contours of
     the bivariate profile likelihood become vertical and horizontal,
     respectively.  In the case of an exactly bivariate normal profile
     likelihood, these two curves would be straight lines giving the
     conditional means of y|x and x|y, and the contours would be
     exactly elliptical.

_A_u_t_h_o_r(_s):

     Originally, D. M. Bates and W. N. Venables.  (For S in 1996.)

_S_e_e _A_l_s_o:

     'profile.glm', 'profile.nls'.

_E_x_a_m_p_l_e_s:

     ## see ?profile.glm for an example using glm fits.

     ## a version of example(profile.nls) from R >= 2.8.0
     fm1 <- nls(demand ~ SSasympOrig(Time, A, lrc), data = BOD)
     pr1 <- profile(fm1, alpha = 0.1)
     MASS:::plot.profile(pr1)
     pairs(pr1) # a little odd since the parameters are highly correlated

     ## an example from ?nls
     x <- -(1:100)/10
     y <- 100 + 10 * exp(x / 2) + rnorm(x)/10
     nlmod <- nls(y ~  Const + A * exp(B * x), start=list(Const=100, A=10, B=1))
     pairs(profile(nlmod))

