initial.sp               package:mgcv               R Documentation

_S_t_a_r_t_i_n_g _v_a_l_u_e_s _f_o_r _m_u_l_t_i_p_l_e _s_m_o_o_t_h_i_n_g _p_a_r_a_m_e_t_e_r _e_s_t_i_m_a_t_i_o_n

_D_e_s_c_r_i_p_t_i_o_n:

     Finds initial smoothing parameter guesses for multiple smoothing
     parameter estimation. The idea is to find values such that the
     estimated degrees of freedom per penalized parameter should be
     well away from 0 and 1 for each penalized parameter, thus ensuring
     that the values are in a region of parameter space where the
     smoothing parameter estimation criterion is varying substantially
     with smoothing parameter value.

_U_s_a_g_e:

     initial.sp(X,S,off,expensive=FALSE)

_A_r_g_u_m_e_n_t_s:

       X: is the model matrix.

       S: is a list of of penalty matrices. 'S[[i]]' is the ith penalty
          matrix, but note that it is not stored as a full matrix, but
          rather as the smallest square matrix including all  the
          non-zero elements of the penalty matrix. Element 1,1 of
          'S[[i]]'  occupies  element 'off[i]', 'off[i]' of the ith
          penalty matrix. Each 'S[[i]]' must be  positive
          semi-definite.  

     off: is an array indicating the first parameter in the parameter
          vector that is  penalized by the penalty involving 'S[[i]]'.

expensive: if 'TRUE' then the overall amount of smoothing is adjusted
          so that the average degrees of freedom per penalized
          parameter is exactly 0.5: this is numerically costly. 

_D_e_t_a_i_l_s:

     Basically uses a crude approximation to the estimated degrees of
     freedom per model coefficient, to try and find smoothing
     parameters which bound these e.d.f.'s away from 0 and 1.

     Usually only called by 'magic' and 'gam'.

_V_a_l_u_e:

     An array of initial smoothing parameter estimates.

_A_u_t_h_o_r(_s):

     Simon N. Wood simon.wood@r-project.org

_S_e_e _A_l_s_o:

     'magic', 'gam.outer', 'gam',

