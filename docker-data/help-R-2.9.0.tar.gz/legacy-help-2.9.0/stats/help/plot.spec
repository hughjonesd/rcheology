plot.spec               package:stats               R Documentation

_P_l_o_t_t_i_n_g _S_p_e_c_t_r_a_l _D_e_n_s_i_t_i_e_s

_D_e_s_c_r_i_p_t_i_o_n:

     Plotting method for objects of class '"spec"'.  For multivariate
     time series it plots the marginal spectra of the series or pairs
     plots of the coherency and phase of the cross-spectra.

_U_s_a_g_e:

     ## S3 method for class 'spec':
     plot(x, add = FALSE, ci = 0.95, log = c("yes", "dB", "no"),
          xlab = "frequency", ylab = NULL, type = "l",
          ci.col = "blue", ci.lty = 3, 
          main = NULL, sub = NULL,
          plot.type = c("marginal", "coherency", "phase"),
          ...)

     plot.spec.phase(x, ci = 0.95,
                     xlab = "frequency", ylab = "phase",
                     ylim = c(-pi, pi), type = "l",
                     main = NULL, ci.col = "blue", ci.lty = 3, ...) 

     plot.spec.coherency(x, ci = 0.95,
                         xlab = "frequency",
                         ylab = "squared coherency",
                         ylim = c(0, 1), type = "l",
                         main = NULL, ci.col = "blue", ci.lty = 3, ...)

_A_r_g_u_m_e_n_t_s:

       x: an object of class '"spec"'.

     add: logical.  If 'TRUE', add to already existing plot. Only valid
          for 'plot.type = "marginal"'. 

      ci: coverage probability for confidence interval.  Plotting of
          the confidence bar/limits is omitted unless 'ci' is strictly
          positive.

     log: If '"dB"', plot on log10 (decibel) scale (as S-PLUS),
          otherwise use conventional log scale or linear scale. 
          Logical values are also accepted.  The default is '"yes"'
          unless 'options(ts.S.compat = TRUE)' has been set, when it is
          '"dB"'.  Only valid for 'plot.type = "marginal"'. 

    xlab: the x label of the plot.

    ylab: the y label of the plot.  If missing a suitable label will be
          constructed.

    type: the type of plot to be drawn, defaults to lines.

  ci.col: colour for plotting confidence bar or confidence intervals
          for coherency and phase.

  ci.lty: line type for confidence intervals for coherency and phase.

    main: overall title for the plot. If missing, a suitable title is
          constructed.

     sub: a sub title for the plot.  Only used for 'plot.type =
          "marginal"'.  If missing, a description of the smoothing is
          used.

plot.type: For multivariate time series, the type of plot required. 
          Only the first character is needed.

ylim, ...: Graphical parameters.

_S_e_e _A_l_s_o:

     'spectrum'

