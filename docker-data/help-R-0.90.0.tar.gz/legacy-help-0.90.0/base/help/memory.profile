

   memory.profile(base)                         R Documentation

   [1mProfile the Usage of Cons Cells[0m

   [1mDescription:[0m

        Lists the usage of the cons cells by `SEXPREC' type.

   [1mUsage:[0m

        memory.profile()

   [1mDetails:[0m

        The current types and their uses are listed in the
        include file `Rinternals.h'. There will be blanks in
        the list corresponding to types that are no longer in
        use (types 11 and 12 at the time of writing). Also
        `FUNSXP' is not included.

   [1mValue:[0m

        A vector of counts, named by the types.

   [1mSee Also:[0m

        `gc' for the overall usage of cons cells.

   [1mExamples:[0m

        memory.profile()

