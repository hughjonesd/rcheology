

   ts.plot(ts)                                  R Documentation

   [1mPlot Multiple Time Series[0m

   [1mDescription:[0m

        Plot sveral time series on a common plot. Unlike
        `plot.ts' the series can have a different time bases,
        but they should have the same frequency.

   [1mUsage:[0m

        ts.plot(..., gpars=list())

   [1mArguments:[0m

        ...: one or more univariate or multivariate time series

      gpars: list of named graphics parameters to be passed to
             the plotting functions

   [1mValue:[0m

        None.

   [1mAuthor(s):[0m

        B.D. Ripley

   [1mSee Also:[0m

        `plot.ts'

   [1mExamples:[0m

        data(UKLungDeaths)
        ts.plot(ldeaths, mdeaths, fdeaths,
                gpars=list(xlab="year", ylab="deaths", lty=c(1:3)))

        data(nottem)
        nott <- window(nottem, end=c(1936,12))
        fit <- arima0(nott,order=c(1,0,0), list(order=c(2,1,0), period=12))
        nott.fore <- predict(fit, n.ahead=36)
        ts.plot(nott, nott.fore$pred, nott.fore$pred+2*nott.fore$se,
                nott.fore$pred-2*nott.fore$se, gpars=list(ylab=""))

