

   match.fun {base}                             R Documentation

   [1mFunction Verification for ``Function Variables''[0m

   [1mDescription:[0m

        This function is called inside functions that take a
        function as argument. It's purpose is to extract the
        desired function object while avoiding undesired match-
        ing to objects of other types.

   [1mUsage:[0m

        match.fun(FUN, descend = TRUE)

   [1mArguments:[0m

        FUN: item to match as function.

    descend: logical; control whether to search past non-func-
             tion objects.

   [1mDetails:[0m

        `match.fun' is not intended to be used at the top level
        since it will perform matching in the parent of the
        caller.

        It is assumed that `FUN' is an argument passed to the
        caller and is a function or a character string contain-
        ing the name of a function.

        Returns an error if no matching function is found.

   [1mValue:[0m

        A function matching `FUN' or an error is generated.

   [1mBugs:[0m

        The `descend' argument is a bit of misnomer and proba-
        bly not actually needed by anything. It may go away in
        the future.

        It is impossible to fully foolproof this. If one
        `attach'es a list or data frame containing a character
        object with the same name of a system function, it will
        be used.

   [1mAuthor(s):[0m

        Peter Dalgaard and Robert Gentleman, based on an ear-
        lier version by Jonathan Rougier

   [1mSee Also:[0m

        `match.arg', `get'

   [1mExamples:[0m

        # Same as get("*"):
        match.fun("*")
        # Overwrite outer with a vector
        outer <- 1:5

        match.fun(outer, descend = FALSE) #-> Error:  not a function

        match.fun(outer) # finds it anyway
        is.function(match.fun("outer")) # as well

