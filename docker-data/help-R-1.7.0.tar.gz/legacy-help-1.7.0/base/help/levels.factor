levels.factor              package:base              R Documentation

_F_a_c_t_o_r _L_e_v_e_l_s _A_s_s_i_g_n_m_e_n_t

_D_e_s_c_r_i_p_t_i_o_n:

     `levels<-' provides a way to alter the levels attribute of factor.
     `value' can be a vector of character strings with length at least
     the the number of levels of `x', or a named list specifying how to
     rename the levels.

_U_s_a_g_e:

     levels(x) <- value

_S_e_e _A_l_s_o:

     `factor', `levels', `levels<-', `nlevels'.

_E_x_a_m_p_l_e_s:

     # assign individual levels
     x <- gl(2, 4, 8)
     levels(x)[1] <- "low"
     levels(x)[2] <- "high"
     x

     # or as a group
     y <- gl(2, 4, 8)
     levels(y) <- c("low", "high")
     y

     # combine some levels
     z <- gl(3, 2, 12)
     levels(z) <- c("A", "B", "A")
     z

     # same, using a named list
     z <- gl(3, 2, 12)
     levels(z) <- list(A=c(1,3), B=2)
     z

     # we can add levels this way:
     f <- factor(c("a","b"))
     levels(f) <- c("c", "a", "b")
     f

     f <- factor(c("a","b"))
     levels(f) <- list(C="C", A="a", B="b")
     f

