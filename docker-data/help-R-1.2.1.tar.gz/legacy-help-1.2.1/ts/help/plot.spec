plot.spec                 package:ts                 R Documentation

_P_l_o_t_t_i_n_g _S_p_e_c_t_r_a_l _D_e_n_s_i_t_i_e_s

_D_e_s_c_r_i_p_t_i_o_n:

     Plotting method for objects of class `"spec"'.  For multivariate
     time series it plots the marginal spectra of the series or pairs
     plots of the coherency and phase of the cross-spectra.

_U_s_a_g_e:

     plot(x, add = FALSE, ci = 0.95, log = c("yes", "dB", "no"),
          xlab = "frequency", ylab = NULL, type = "l", ci.col = "blue",
          main = NULL, sub = NULL,
          plot.type = c("marginal", "coherency", "phase"),
          ci.lty = 3, ...)

_A_r_g_u_m_e_n_t_s:

       x: an object of class `"spec"'.

     add: logical.  If `TRUE', add to already existing plot.

      ci: Coverage probability for confidence interval.  Plotting of
          the confidence bar is omitted unless `ci' is strictly
          positive.

     log: If `"dB"', plot on log10 (decibel) scale (as S-PLUS),
          otherwise use conventional log scale or linear scale. 
          Logical values are also accepted.  The default is `"yes"'
          unless `options(ts.S.compat = TRUE)' has been set, when it is
          `"dB"'.

    xlab: the x label of the plot.

    ylab: the y label of the plot.

    type: the type of plot to be drawn, defaults to lines.

  ci.col: Colour for plotting confidence bar or confidence intervals
          for coherency and phase.

    main: overall title for the plot.

     sub: a sub title for the plot.

plot.type: For multivariate time series, the type of plot required. 
          Only the first character is needed.

  ci.lty: line type for confidence intervals for coherency and phase.

     ...: Further graphical parameters.

_S_e_e _A_l_s_o:

     `spectrum'

