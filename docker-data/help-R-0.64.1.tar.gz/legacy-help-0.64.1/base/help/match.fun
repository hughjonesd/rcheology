

   [1mFunction Verification for ``Function Variables''[0m

        match.fun(FUN, descend=TRUE)

   [1mArguments:[0m

        FUN: function, e.g. as passed to `outer'.

    descend: logical; control whether to search under non-func-
             tion objects.

   [1mDescription:[0m

        Matches `FUN' to a function, where `FUN' can be a char-
        acter (string), e.g., `"*"' or `"fred"', or a function
        such as `pmax'.

        Returns an error if no matching function is found.

   [1mDetails:[0m

        If `descend=TRUE', `match.fun' will look underneath
        non-function objects with the given name; otherwise if
        `FUN' points to a non-function object then an error is
        generated.

        This is now used in base functions such as `apply',
        `lapply', `outer', `sweep', and the like.

   [1mValue:[0m

        A function matching `FUN' or an error is generated.

   [1mBug/Feature:[0m

        A character argument to `FUN' is always matched to a
        function, even if there is a non-function object higher
        up the search list with the same name.

   [1mAuthor(s):[0m

        Jonathan Rougier

   [1mSee Also:[0m

        `match.arg'

   [1mExamples:[0m

        # Same as get("*"):
        match.fun("*")
        # Overwrite outer with a vector
        outer <- 1:5

        match.fun(outer, descend = FALSE) #-> Error:  not a function

        match.fun(outer) # finds it anyway
        is.function(match.fun("outer")) # as well

